/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* #undef ENABLE_NLS */
/* #undef HAVE_CATGETS */
/* #undef HAVE_GETTEXT */
/* #undef HAVE_LC_MESSAGES */
/* #undef HAVE_STPCPY */
/* #undef HAVE_LIBSM */
/* #undef PACKAGE_LOCALE_DIR */
#define PACKAGE_DATA_DIR "/usr/local/share/spucfg"
#define PACKAGE_SOURCE_DIR "/home/pete/projects/spucfg"

/* Name of package */
#define PACKAGE "spucfg"

/* Version number of package */
#define VERSION "0.1"

